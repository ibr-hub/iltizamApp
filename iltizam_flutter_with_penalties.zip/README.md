# الالتزام — Flutter Android release candidate

نسخة مرشحة للبناء مع تثبيت إصدارات أدوات Android وFlutter لتجنب تغيّر بيئة البناء تلقائيًا.

## إصدارات البناء المثبتة

- Flutter: 3.47.6 (Dart 3.13.5)
- Java/JDK: 17
- Android Gradle Plugin: 8.11.1
- Kotlin Gradle Plugin: 2.2.20
- Gradle: 8.14
- Android compile SDK / target SDK: 35
- Android build tools: 35.0.0
- Android NDK: 27.0.12077973
- Minimum Android: API 28 (Android 9)

راجع `VERSION_AUDIT.md` لمصفوفة الإصدارات وأسباب اختيارها.

## طريقة البناء

هذا الأرشيف يحتوي مشروع Flutter من الجذر مباشرة. عند رفع ملفات المشروع إلى مستودع مستقل، يجب أن تكون `pubspec.yaml` و`lib/` و`android/` و`codemagic.yaml` في جذر المستودع. لا يحتاج workflow إلى فك ملف ZIP داخل CodeMagic.

يبدأ workflow بفحص الملفات والإصدارات، ثم ينفذ `flutter pub get` و`flutter analyze` واختبار واجهة بسيط، ولا يبدأ بناء APK إلا إذا نجحت الخطوات السابقة.

## حدود التحقق

لم يتوفر Flutter/Dart SDK في بيئة إعداد الأرشيف، لذلك لم أتمكن من تشغيل التحليل أو الاختبارات أو إنتاج APK هنا. لا أصف هذه النسخة بأنها اجتازت بناءً فعليًا. كما أن هذا التطبيق ما يزال نموذجًا أوليًا بميزات محلية؛ أذونات البصمة وحدها لا تعني اكتمال تسجيل الدخول البيومتري أو الإشعارات المجدولة أو مزامنة الأسرة.
