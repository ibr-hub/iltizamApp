# Iltizam Android build version audit

This release candidate pins the toolchain to prevent Codemagic's `stable` channel from silently changing between builds.

| Component | Pinned value | Reason |
|---|---:|---|
| Flutter | 3.47.6 | Explicit stable release instead of moving `stable` channel |
| Dart SDK | Bundled with Flutter 3.47.6 (3.13.5) | `intl 0.20.3` requires Dart 3.9+ |
| Java / JDK | 17 | Required by Android Gradle Plugin 8.x |
| Android Gradle Plugin | 8.11.1 | Compatible with Kotlin Gradle Plugin 2.2.20; requires Gradle 8.13+ |
| Kotlin Gradle Plugin | 2.2.20 | Meets the minimum reported by the current Flutter build failure; Kotlin's compatibility table supports AGP through 8.11.1 and Gradle through 8.14 |
| Gradle wrapper distribution | 8.14 | Inside Kotlin 2.2.20's documented supported range and above AGP 8.11.1's minimum |
| Android compile SDK | 35 | Explicit compile target |
| Android build tools | 35.0.0 | Explicit version compatible with AGP 8.11.x |
| Android NDK | 27.0.12077973 | Explicit NDK version available in Codemagic |
| Android target SDK | 35 | Preserves existing project target |
| Android minimum SDK | 28 (Android 9) | Preserves existing project minimum |
| Kotlin/JVM bytecode target | 17 | Aligned with Java compile target and build JDK |
| intl | ^0.20.3 | Existing localization dependency; requires Dart >=3.9 |
| shared_preferences | ^2.3.2 | Existing local key-value storage dependency |
| flutter_lints | ^4.0.0 | Existing lint dependency |

## Build gates

1. Check project structure and print actual toolchain versions.
2. Resolve Dart dependencies.
3. Run static analysis.
4. Run an Arabic RTL widget smoke test with mocked SharedPreferences.
5. Build the release APK only if the previous steps pass.

## Important verification limit

The Flutter and Dart SDKs are not installed in the file-editing environment used to prepare this archive. Therefore `flutter pub get`, `flutter analyze`, `flutter test`, and `flutter build apk --release` have **not** been executed here. This archive is statically audited, not a build-verified APK. The Codemagic workflow is deliberately configured to stop before the APK build if analysis or the smoke test fails.
