@echo off
setlocal
set GRADLE_VERSION=8.14.3
set GRADLE_HOME=%USERPROFILE%\.gradle\manual-distributions\gradle-%GRADLE_VERSION%
if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo This source archive bootstraps Gradle automatically on Linux CI. Please generate the standard Gradle wrapper on Windows.
  exit /b 1
)
call "%GRADLE_HOME%\bin\gradle.bat" %*
