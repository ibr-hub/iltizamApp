package com.example.iltizam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
