import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = await AppStore.create();
  runApp(IltizamApp(store: store));
}

class AppStore extends ChangeNotifier {
  AppStore(this.prefs) {
    _load();
  }
  final SharedPreferences prefs;
  String mode = 'الزوج';
  String name = 'مستخدم الالتزام';
  bool darkMode = false;
  bool showFamily = true;
  int points = 120;
  int streak = 3;
  int totalPositive = 0;
  int totalViolations = 0;
  final List<Map<String, dynamic>> positives = [];
  final List<Map<String, dynamic>> violations = [];
  final List<Map<String, dynamic>> rewards = [];
  final List<Map<String, dynamic>> redemptions = [];
  final List<Map<String, dynamic>> penalties = [];
  final List<Map<String, dynamic>> penaltyHistory = [];

  static Future<AppStore> create() async => AppStore(await SharedPreferences.getInstance());

  void _load() {
    mode = prefs.getString('mode') ?? mode;
    name = prefs.getString('name') ?? name;
    darkMode = prefs.getBool('darkMode') ?? false;
    showFamily = prefs.getBool('showFamily') ?? true;
    points = prefs.getInt('points') ?? 120;
    streak = prefs.getInt('streak') ?? 3;
    totalPositive = prefs.getInt('totalPositive') ?? 0;
    totalViolations = prefs.getInt('totalViolations') ?? 0;
    _readList('positives', positives);
    _readList('violations', violations);
    _readList('rewards', rewards);
    _readList('redemptions', redemptions);
    _readList('penalties', penalties);
    _readList('penaltyHistory', penaltyHistory);
    if (penalties.isEmpty) {
      penalties.addAll([
        {'id': 'p1', 'title': 'مهمة إصلاحية متفق عليها', 'description': 'إنجاز مهمة منزلية بسيطة أو ترتيب مساحة مشتركة', 'category': 'مسؤولية أسرية', 'requiresApproval': true, 'enabled': true},
        {'id': 'p2', 'title': 'جلسة مراجعة ذاتية', 'description': 'تخصيص عشر دقائق لمراجعة السبب ووضع خطة للتحسين', 'category': 'تطوير الذات', 'requiresApproval': false, 'enabled': true},
        {'id': 'p3', 'title': 'تعويض الوقت', 'description': 'تخصيص وقت مناسب لتعويض مهمة أو التزام فائت', 'category': 'إدارة الوقت', 'requiresApproval': true, 'enabled': true},
      ]);
      _save();
    }
    if (rewards.isEmpty) {
      rewards.addAll([
        {'id': 'r1', 'title': 'اختيار وجبة مفضلة', 'description': 'اختيار وجبة للعائلة', 'cost': 80, 'enabled': true},
        {'id': 'r2', 'title': 'وقت ترفيه إضافي', 'description': 'ساعة من النشاط المفضل', 'cost': 100, 'enabled': true},
        {'id': 'r3', 'title': 'هدية رمزية', 'description': 'هدية يتم الاتفاق عليها', 'cost': 200, 'enabled': true},
      ]);
      _save();
    }
  }

  void _readList(String key, List<Map<String, dynamic>> target) {
    final raw = prefs.getString(key);
    if (raw == null) return;
    try {
      final decoded = jsonDecode(raw) as List<dynamic>;
      target.addAll(decoded.map((e) => Map<String, dynamic>.from(e as Map)));
    } catch (_) {
      // Ignore corrupt optional local data rather than crashing the app.
    }
  }

  Future<void> _save() async {
    await prefs.setString('mode', mode);
    await prefs.setString('name', name);
    await prefs.setBool('darkMode', darkMode);
    await prefs.setBool('showFamily', showFamily);
    await prefs.setInt('points', points);
    await prefs.setInt('streak', streak);
    await prefs.setInt('totalPositive', totalPositive);
    await prefs.setInt('totalViolations', totalViolations);
    await prefs.setString('positives', jsonEncode(positives));
    await prefs.setString('violations', jsonEncode(violations));
    await prefs.setString('rewards', jsonEncode(rewards));
    await prefs.setString('redemptions', jsonEncode(redemptions));
    await prefs.setString('penalties', jsonEncode(penalties));
    await prefs.setString('penaltyHistory', jsonEncode(penaltyHistory));
  }

  Future<void> addPositive(String title, int value, String category) async {
    positives.insert(0, {'title': title, 'points': value, 'category': category, 'date': DateTime.now().toIso8601String()});
    points += value;
    totalPositive++;
    streak++;
    await _save();
    notifyListeners();
  }

  Future<void> addViolation(String title, int value, String category) async {
    violations.insert(0, {'title': title, 'points': value, 'category': category, 'date': DateTime.now().toIso8601String()});
    points = (points - value).clamp(0, 1 << 30).toInt();
    totalViolations++;
    streak = 0;
    await _save();
    notifyListeners();
  }

  Future<void> addPenalty({required String title, required String description, required String category, required bool requiresApproval}) async {
    penalties.insert(0, {'id': DateTime.now().microsecondsSinceEpoch.toString(), 'title': title, 'description': description, 'category': category, 'requiresApproval': requiresApproval, 'enabled': true});
    await _save();
    notifyListeners();
  }

  Future<void> togglePenalty(Map<String, dynamic> penalty) async {
    penalty['enabled'] = !(penalty['enabled'] == true);
    await _save();
    notifyListeners();
  }

  Future<void> recordPenalty(Map<String, dynamic> penalty) async {
    penaltyHistory.insert(0, {'id': DateTime.now().microsecondsSinceEpoch.toString(), 'title': penalty['title'], 'category': penalty['category'], 'status': penalty['requiresApproval'] == true ? 'بانتظار الموافقة' : 'مسجلة', 'date': DateTime.now().toIso8601String(), 'recordedBy': mode});
    await _save();
    notifyListeners();
  }

  Future<void> setPenaltyStatus(Map<String, dynamic> record, String status) async {
    record['status'] = status;
    await _save();
    notifyListeners();
  }

  Future<bool> redeem(Map<String, dynamic> reward) async {
    final cost = (reward['cost'] as num).toInt();
    if (points < cost) return false;
    points -= cost;
    redemptions.insert(0, {'title': reward['title'], 'cost': cost, 'status': 'بانتظار الموافقة', 'date': DateTime.now().toIso8601String()});
    await _save();
    notifyListeners();
    return true;
  }

  Future<void> setMode(String value) async { mode = value; await _save(); notifyListeners(); }
  Future<void> setDark(bool value) async { darkMode = value; await _save(); notifyListeners(); }
  Future<void> setFamily(bool value) async { showFamily = value; await _save(); notifyListeners(); }
  Future<void> setName(String value) async { name = value; await _save(); notifyListeners(); }
}

class IltizamApp extends StatelessWidget {
  const IltizamApp({super.key, required this.store});
  final AppStore store;
  @override
  Widget build(BuildContext context) => AnimatedBuilder(
    animation: store,
    builder: (context, _) => MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'الالتزام',
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      themeMode: store.darkMode ? ThemeMode.dark : ThemeMode.light,
      theme: _theme(Brightness.light),
      darkTheme: _theme(Brightness.dark),
      builder: (context, child) => Directionality(textDirection: TextDirection.rtl, child: child ?? const SizedBox.shrink()),
      home: MainShell(store: store),
    ),
  );
  ThemeData _theme(Brightness brightness) => ThemeData(
    useMaterial3: true,
    brightness: brightness,
    colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF087F70), brightness: brightness),
    scaffoldBackgroundColor: brightness == Brightness.light ? const Color(0xFFF5F7F6) : const Color(0xFF101715),
    appBarTheme: const AppBarTheme(centerTitle: false),
    cardTheme: CardThemeData(elevation: 0, margin: EdgeInsets.zero, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
    inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)), filled: true),
  );
}

class MainShell extends StatefulWidget {
  const MainShell({super.key, required this.store});
  final AppStore store;
  @override State<MainShell> createState() => _MainShellState();
}
class _MainShellState extends State<MainShell> {
  int index = 0;
  @override Widget build(BuildContext context) {
    final pages = [DashboardPage(store: widget.store), PositivesPage(store: widget.store), ViolationsPage(store: widget.store), RewardsPage(store: widget.store), ReportsPage(store: widget.store), SettingsPage(store: widget.store)];
    final titles = ['الرئيسية', 'الحسنات', 'المخالفات', 'المكافآت', 'التقارير', 'الإعدادات'];
    return Scaffold(
      appBar: AppBar(title: Text('الالتزام · ${titles[index]}'), actions: [Padding(padding: const EdgeInsetsDirectional.only(end: 16), child: Center(child: Text(widget.store.mode, style: const TextStyle(fontWeight: FontWeight.w700))))]),
      body: SafeArea(child: IndexedStack(index: index, children: pages)),
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (v) => setState(() => index = v), destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
        NavigationDestination(icon: Icon(Icons.favorite_border), selectedIcon: Icon(Icons.favorite), label: 'الحسنات'),
        NavigationDestination(icon: Icon(Icons.warning_amber_outlined), selectedIcon: Icon(Icons.warning), label: 'المخالفات'),
        NavigationDestination(icon: Icon(Icons.card_giftcard_outlined), selectedIcon: Icon(Icons.card_giftcard), label: 'المكافآت'),
        NavigationDestination(icon: Icon(Icons.insights_outlined), selectedIcon: Icon(Icons.insights), label: 'التقارير'),
        NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
      ]),
    );
  }
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(22), decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xFF087F70), Color(0xFF125B54)])), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('أهلًا، ${store.name}', style: const TextStyle(color: Colors.white70)), const SizedBox(height: 8), const Text('خطوة صغيرة كل يوم، تصنع فرقًا كبيرًا', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.bold)), const SizedBox(height: 20), Row(children: [Expanded(child: _heroStat('رصيد النقاط', '${store.points}', Icons.stars)), const SizedBox(width: 12), Expanded(child: _heroStat('أيام الالتزام', '${store.streak}', Icons.local_fire_department))])]),
    const SizedBox(height: 18), const SectionTitle(title: 'ملخص اليوم', subtitle: 'تابع تقدمك بخطوات واضحة'), const SizedBox(height: 10),
    Row(children: [Expanded(child: StatCard(title: 'الحسنات المسجلة', value: '${store.totalPositive}', icon: Icons.favorite, color: const Color(0xFF087F70))), const SizedBox(width: 10), Expanded(child: StatCard(title: 'المخالفات', value: '${store.totalViolations}', icon: Icons.warning_amber, color: const Color(0xFFC17B26)))]),
    if (store.showFamily) ...[const SizedBox(height: 20), const SectionTitle(title: 'لوحة الأسرة', subtitle: 'مساحة مشتركة للتشجيع والتعاون'), const SizedBox(height: 10), Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [const CircleAvatar(child: Icon(Icons.diversity_3)), const SizedBox(width: 12), const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('هدف الأسرة', style: TextStyle(fontWeight: FontWeight.bold)), Text('التشجيع والتقدم معًا دون مقارنة جارحة') ])), Icon(Icons.chevron_left, color: Theme.of(context).colorScheme.primary)])))],
    const SizedBox(height: 20), const SectionTitle(title: 'إضافة سريعة', subtitle: 'سجّل إنجازك أو راجع مكافآتك'), const SizedBox(height: 10),
    Row(children: [Expanded(child: FilledButton.icon(onPressed: () => _quickAdd(context, store, true), icon: const Icon(Icons.add), label: const Text('حسنة جديدة'))), const SizedBox(width: 10), Expanded(child: OutlinedButton.icon(onPressed: () => _quickAdd(context, store, false), icon: const Icon(Icons.remove), label: const Text('تسجيل مخالفة'))]),
    const SizedBox(height: 20), const SectionTitle(title: 'آخر الأنشطة'), const SizedBox(height: 8),
    ...[...store.positives.take(3).map((e) => ActivityTile(item: e, positive: true)), ...store.violations.take(2).map((e) => ActivityTile(item: e, positive: false))],
    if (store.positives.isEmpty && store.violations.isEmpty) const EmptyState(message: 'لم تسجّل أي نشاط بعد. ابدأ بخطوة إيجابية اليوم.'),
  ]);
}
Widget _heroStat(String label, String value, IconData icon) => Container(padding: const EdgeInsets.all(14), decoration: BoxDecoration(color: Colors.white.withValues(alpha: .13), borderRadius: BorderRadius.circular(16)), child: Row(children: [Icon(icon, color: Colors.white), const SizedBox(width: 8), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(value, style: const TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.bold)), Text(label, style: const TextStyle(color: Colors.white70, fontSize: 12))]))]));

class PositivesPage extends StatelessWidget { const PositivesPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle(title: 'سجل الحسنات', subtitle: 'الأفعال الإيجابية تزيد رصيدك'), const SizedBox(height: 12), FilledButton.icon(onPressed: () => _showEntryDialog(context, store, true), icon: const Icon(Icons.add), label: const Text('إضافة حسنة')), const SizedBox(height: 12), if (store.positives.isEmpty) const EmptyState(message: 'لم تتم إضافة حسنات بعد') else ...store.positives.map((e) => ActivityTile(item: e, positive: true))]); }
class ViolationsPage extends StatelessWidget { const ViolationsPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle(title: 'سجل المخالفات', subtitle: 'المراجعة تساعد على تحسين العادات'), const SizedBox(height: 12), FilledButton.tonalIcon(onPressed: () => _showEntryDialog(context, store, false), icon: const Icon(Icons.add), label: const Text('تسجيل مخالفة')), const SizedBox(height: 8), OutlinedButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => PenaltiesPage(store: store))), icon: const Icon(Icons.rule_folder_outlined), label: const Text('إدارة العقوبات وسجلها')), const SizedBox(height: 12), if (store.violations.isEmpty) const EmptyState(message: 'لا توجد مخالفات مسجلة') else ...store.violations.map((e) => ActivityTile(item: e, positive: false))]); }

class PenaltiesPage extends StatelessWidget {
  const PenaltiesPage({super.key, required this.store});
  final AppStore store;

  Future<void> _addPenalty(BuildContext context) async {
    final title = TextEditingController();
    final description = TextEditingController();
    var category = 'مسؤولية أسرية';
    var requiresApproval = true;
    final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => AlertDialog(
      title: const Text('إضافة عقوبة متفق عليها'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(controller: title, decoration: const InputDecoration(labelText: 'اسم الإجراء')),
        const SizedBox(height: 10),
        TextField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'الوصف وطريقة التنفيذ')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'الفئة'), items: const ['مسؤولية أسرية', 'تطوير الذات', 'إدارة الوقت', 'تعويض مهمة', 'أخرى'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(), onChanged: (v) => setState(() => category = v ?? category)),
        const SizedBox(height: 8),
        SwitchListTile(contentPadding: EdgeInsets.zero, title: const Text('تتطلب موافقة قبل التنفيذ'), value: requiresApproval, onChanged: (v) => setState(() => requiresApproval = v)),
        const Text('استخدم إجراءات آمنة ومحترمة ومتفقًا عليها، ولا تستخدم الإيذاء أو الإهانة أو الحرمان من الحقوق الأساسية.', style: TextStyle(fontSize: 12)),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ'))],
    )));
    if (ok != true) return;
    if (title.text.trim().isEmpty || description.text.trim().isEmpty) {
      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسم الإجراء ووصفه')));
      return;
    }
    await store.addPenalty(title: title.text.trim(), description: description.text.trim(), category: category, requiresApproval: requiresApproval);
  }

  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('إدارة العقوبات')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const SectionTitle(title: 'إجراءات تصحيحية متفق عليها', subtitle: 'هذه الوحدة مستقلة عن خصم النقاط والمكافآت'),
      const SizedBox(height: 12),
      FilledButton.icon(onPressed: () => _addPenalty(context), icon: const Icon(Icons.add), label: const Text('إضافة عقوبة')),
      const SizedBox(height: 12),
      if (store.penalties.isEmpty) const EmptyState(message: 'لم تتم إضافة عقوبات بعد') else ...store.penalties.map((p) => Card(margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [Expanded(child: Text('${p['title']}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))), Switch(value: p['enabled'] == true, onChanged: (_) => store.togglePenalty(p))]),
        Text('${p['description']}'), const SizedBox(height: 6),
        Wrap(spacing: 6, runSpacing: 6, children: [Chip(label: Text('${p['category']}')), Chip(label: Text(p['requiresApproval'] == true ? 'تتطلب موافقة' : 'لا تتطلب موافقة')), Chip(label: Text(p['enabled'] == true ? 'مفعلة' : 'معطلة'))]),
        const SizedBox(height: 8),
        Align(alignment: AlignmentDirectional.centerEnd, child: FilledButton.tonalIcon(onPressed: p['enabled'] == true ? () async { await store.recordPenalty(p); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(p['requiresApproval'] == true ? 'سُجل الإجراء بانتظار الموافقة' : 'تم تسجيل الإجراء'))); } : null, icon: const Icon(Icons.fact_check_outlined), label: const Text('تسجيل الإجراء'))),
      ])))),
      const SizedBox(height: 20),
      const SectionTitle(title: 'سجل الإجراءات', subtitle: 'متابعة الحالة والتاريخ'),
      const SizedBox(height: 8),
      if (store.penaltyHistory.isEmpty) const EmptyState(message: 'لا توجد إجراءات مسجلة') else ...store.penaltyHistory.map((r) => Card(margin: const EdgeInsets.only(bottom: 8), child: ListTile(leading: const Icon(Icons.history), title: Text('${r['title']}'), subtitle: Text('${r['category']} · ${r['recordedBy']} · ${r['date'].toString().split('T').first}'), trailing: PopupMenuButton<String>(tooltip: 'تغيير الحالة', onSelected: (v) => store.setPenaltyStatus(r, v), itemBuilder: (_) => const [PopupMenuItem(value: 'بانتظار الموافقة', child: Text('بانتظار الموافقة')), PopupMenuItem(value: 'تمت الموافقة', child: Text('تمت الموافقة')), PopupMenuItem(value: 'مرفوضة', child: Text('مرفوضة')), PopupMenuItem(value: 'مكتملة', child: Text('مكتملة'))], child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [const Icon(Icons.more_vert), Text('${r['status']}', style: const TextStyle(fontSize: 10))]))))),
    ]),
  );
}

Future<void> _quickAdd(BuildContext context, AppStore store, bool positive) => _showEntryDialog(context, store, positive);
Future<void> _showEntryDialog(BuildContext context, AppStore store, bool positive) async {
  final title = TextEditingController(); final points = TextEditingController(text: positive ? '10' : '5'); String category = positive ? 'عبادة' : 'سلوك';
  final ok = await showDialog<bool>(context: context, builder: (ctx) => StatefulBuilder(builder: (ctx, setState) => AlertDialog(title: Text(positive ? 'إضافة حسنة' : 'تسجيل مخالفة'), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [TextField(controller: title, autofocus: true, decoration: const InputDecoration(labelText: 'اسم النشاط')), const SizedBox(height: 12), TextField(controller: points, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: positive ? 'النقاط المكتسبة' : 'النقاط المخصومة')), const SizedBox(height: 12), DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'الفئة'), items: (positive ? ['عبادة', 'قرآن', 'علم', 'سلوك', 'صحة', 'أسرة'] : ['سلوك', 'وقت', 'مسؤولية', 'أسرة', 'أخرى']).map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(), onChanged: (v) => setState(() => category = v ?? category))])), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ'))])));
  if (ok != true) return;
  final n = int.tryParse(points.text) ?? 0;
  if (title.text.trim().isEmpty || n <= 0) { if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('أدخل اسمًا صحيحًا وعدد نقاط أكبر من صفر'))); return; }
  if (positive) { await store.addPositive(title.text.trim(), n, category); } else { await store.addViolation(title.text.trim(), n, category); }
  if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(positive ? 'تم تسجيل الحسنة وإضافة النقاط' : 'تم تسجيل المخالفة وخصم النقاط')));
}

class RewardsPage extends StatelessWidget { const RewardsPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle(title: 'متجر المكافآت', subtitle: 'استبدل نقاطك بمكافآت متفق عليها'), const SizedBox(height: 12), ...store.rewards.where((r) => r['enabled'] == true).map((r) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [Container(width: 50, height: 50, decoration: BoxDecoration(color: Theme.of(context).colorScheme.primaryContainer, borderRadius: BorderRadius.circular(14)), child: const Icon(Icons.card_giftcard)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('${r['title']}', style: const TextStyle(fontWeight: FontWeight.bold)), Text('${r['description']}'), Text('${r['cost']} نقطة', style: TextStyle(color: Theme.of(context).colorScheme.primary, fontWeight: FontWeight.bold))])), FilledButton.tonal(onPressed: () async { final success = await store.redeem(r); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(success ? 'تم طلب المكافأة، وهي بانتظار الموافقة' : 'رصيدك لا يكفي لهذه المكافأة'))); }, child: const Text('استبدال'))]))), const SizedBox(height: 20), const SectionTitle(title: 'طلبات الاستبدال'), const SizedBox(height: 8), if (store.redemptions.isEmpty) const EmptyState(message: 'لا توجد طلبات استبدال') else ...store.redemptions.map((r) => ListTile(leading: const Icon(Icons.hourglass_top), title: Text('${r['title']}'), subtitle: Text('${r['status']} · ${r['cost']} نقطة')))]); }

class ReportsPage extends StatelessWidget { const ReportsPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) { final totalEarned = store.positives.fold<int>(0, (s, e) => s + ((e['points'] as num?)?.toInt() ?? 0)); final totalLost = store.violations.fold<int>(0, (s, e) => s + ((e['points'] as num?)?.toInt() ?? 0)); return ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle(title: 'تقارير التقدم', subtitle: 'نظرة عامة على رحلتك'), const SizedBox(height: 14), StatCard(title: 'إجمالي النقاط المكتسبة', value: '$totalEarned', icon: Icons.trending_up, color: const Color(0xFF087F70)), const SizedBox(height: 10), StatCard(title: 'إجمالي النقاط المخصومة', value: '$totalLost', icon: Icons.trending_down, color: const Color(0xFFC17B26)), const SizedBox(height: 10), StatCard(title: 'طلبات المكافآت', value: '${store.redemptions.length}', icon: Icons.card_giftcard, color: const Color(0xFF6478C8)), const SizedBox(height: 20), const SectionTitle(title: 'مؤشرات الالتزام'), const SizedBox(height: 8), Card(child: Padding(padding: const EdgeInsets.all(16), child: Column(children: [_progressRow('الأفعال الإيجابية', store.totalPositive, store.totalPositive + store.totalViolations), const SizedBox(height: 14), _progressRow('المخالفات المسجلة', store.totalViolations, store.totalPositive + store.totalViolations)])))]); }
}
Widget _progressRow(String title, int value, int total) { final ratio = total == 0 ? 0.0 : value / total; return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Row(children: [Expanded(child: Text(title)), Text('$value')]), const SizedBox(height: 6), LinearProgressIndicator(value: ratio, minHeight: 8, borderRadius: BorderRadius.circular(8))]); }

class SettingsPage extends StatelessWidget { const SettingsPage({super.key, required this.store}); final AppStore store;
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [const SectionTitle(title: 'الإعدادات والخصوصية', subtitle: 'خصّص تجربتك في التطبيق'), const SizedBox(height: 12), Card(child: Column(children: [ListTile(leading: const Icon(Icons.person_outline), title: const Text('الاسم المعروض'), subtitle: Text(store.name), trailing: const Icon(Icons.edit), onTap: () async { final c = TextEditingController(text: store.name); final ok = await showDialog<bool>(context: context, builder: (ctx) => AlertDialog(title: const Text('تعديل الاسم'), content: TextField(controller: c, decoration: const InputDecoration(labelText: 'الاسم')), actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')), FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('حفظ'))])); if (ok == true && c.text.trim().isNotEmpty) await store.setName(c.text.trim()); }), const Divider(height: 1), ListTile(leading: const Icon(Icons.swap_horiz), title: const Text('وضع الاستخدام'), subtitle: Text(store.mode), trailing: const Icon(Icons.chevron_left), onTap: () => showModalBottomSheet<void>(context: context, builder: (ctx) => SafeArea(child: Column(mainAxisSize: MainAxisSize.min, children: ['الزوج', 'الزوجة'].map((m) => ListTile(title: Text(m), leading: Icon(store.mode == m ? Icons.radio_button_checked : Icons.radio_button_off), onTap: () async { await store.setMode(m); if (ctx.mounted) Navigator.pop(ctx); })).toList())))), const Divider(height: 1), SwitchListTile(secondary: const Icon(Icons.diversity_3), title: const Text('إظهار لوحة الأسرة'), subtitle: const Text('إظهار مساحة الأسرة المشتركة على الرئيسية'), value: store.showFamily, onChanged: store.setFamily), const Divider(height: 1), SwitchListTile(secondary: const Icon(Icons.dark_mode_outlined), title: const Text('الوضع الداكن'), value: store.darkMode, onChanged: store.setDark), const Divider(height: 1), const ListTile(leading: Icon(Icons.lock_outline), title: Text('الخصوصية والأمان'), subtitle: Text('البيانات محفوظة محليًا على هذا الجهاز في هذه النسخة التجريبية.'))])), const SizedBox(height: 18), const Card(child: Padding(padding: EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('عن التطبيق', style: TextStyle(fontWeight: FontWeight.bold)), SizedBox(height: 6), Text('الالتزام — أداة للتشجيع على العادات الإيجابية والتعاون الأسري.'), SizedBox(height: 6), Text('الإصدار 1.0.0')])))]); }

class SectionTitle extends StatelessWidget { const SectionTitle({super.key, required this.title, this.subtitle}); final String title; final String? subtitle;
  @override Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.bold)), if (subtitle != null) ...[const SizedBox(height: 3), Text(subtitle!, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant))]]); }
class StatCard extends StatelessWidget { const StatCard({super.key, required this.title, required this.value, required this.icon, required this.color}); final String title, value; final IconData icon; final Color color;
  @override Widget build(BuildContext context) => Card(child: Padding(padding: const EdgeInsets.all(16), child: Row(children: [Container(padding: const EdgeInsets.all(10), decoration: BoxDecoration(color: color.withValues(alpha: .12), borderRadius: BorderRadius.circular(14)), child: Icon(icon, color: color)), const SizedBox(width: 12), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(title, style: Theme.of(context).textTheme.bodyMedium), const SizedBox(height: 4), Text(value, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold))]))]))); }
class ActivityTile extends StatelessWidget { const ActivityTile({super.key, required this.item, required this.positive}); final Map<String, dynamic> item; final bool positive;
  @override Widget build(BuildContext context) => Card(child: ListTile(leading: CircleAvatar(backgroundColor: (positive ? const Color(0xFF087F70) : const Color(0xFFC17B26)).withValues(alpha: .12), child: Icon(positive ? Icons.favorite : Icons.warning_amber, color: positive ? const Color(0xFF087F70) : const Color(0xFFC17B26))), title: Text('${item['title']}'), subtitle: Text('${item['category'] ?? ''}'), trailing: Text('${positive ? '+' : '-'}${item['points']} نقطة', style: TextStyle(fontWeight: FontWeight.bold, color: positive ? const Color(0xFF087F70) : const Color(0xFFC17B26))))); }
class EmptyState extends StatelessWidget { const EmptyState({super.key, required this.message}); final String message;
  @override Widget build(BuildContext context) => Padding(padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 18), child: Column(children: [Icon(Icons.inbox_outlined, size: 44, color: Theme.of(context).colorScheme.onSurfaceVariant), const SizedBox(height: 10), Text(message, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: Theme.of(context).colorScheme.onSurfaceVariant))])); }
