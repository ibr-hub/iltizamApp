import 'package:flutter_test/flutter_test.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:iltizam/main.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    SharedPreferences.setMockInitialValues({});
  });

  testWidgets('Arabic RTL home screen renders', (tester) async {
    final prefs = await SharedPreferences.getInstance();
    final store = AppStore(prefs);

    await tester.pumpWidget(IltizamApp(store: store));
    await tester.pumpAndSettle();

    expect(find.text('الالتزام · الرئيسية'), findsOneWidget);
    expect(find.text('لوحة الأسرة'), findsOneWidget);
    expect(find.text('رصيد النقاط'), findsOneWidget);
  });
}
